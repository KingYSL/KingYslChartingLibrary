﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KingYslChartingLibv1._0.Enums
{
    public enum TickOrientation
    {
        Major, Minor
    }
}
